package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.udojava.evalex.Expression

class MainActivity : AppCompatActivity() {

    private lateinit var textDisplay: TextView
    private lateinit var textInput: TextView
    private var input= ""
    private var output= ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Initialize TextViews
        textDisplay = findViewById(R.id.text_display)
        textInput = findViewById(R.id.text_input)

        // set up button listener
        SetButtonListeners()
    }
    private fun SetButtonListeners(){
        val buttons = listOf(
            Pair(R.id.button1,"C"),Pair(R.id.button2,"^"),Pair(R.id.button3,"()"),
            Pair(R.id.button5,"7"),Pair(R.id.button6,"8"),Pair(R.id.button7,"9"),Pair(R.id.button8,"÷"),
            Pair(R.id.button9,"4"),Pair(R.id.button10,"5"),Pair(R.id.button11,"6"),Pair(R.id.button12,"×"),
            Pair(R.id.button13,"1"),Pair(R.id.button14,"2"),Pair(R.id.button15,"3"),Pair(R.id.button16,"-"),
            Pair(R.id.button17,"."),Pair(R.id.button18,"0"),Pair(R.id.button19,"+"),Pair(R.id.button20,"=")
        )
        for ((buttonId,value) in buttons){
            findViewById<Button>(buttonId).setOnClickListener{
                handleInput(value)
            }
        }
        //Handle backspace button
        findViewById<ImageButton>(R.id.button4).setOnClickListener{
            handleBackspace()
        }
    }

    private fun handleInput(value: String){
        when(value){
            "C" -> clearAll()
            "=" -> calculateResult()
            "()" -> addParenttheses()
            else -> {
                input += when(value){
                    "÷" -> "/"
                    "×" -> "*"
                    else -> value
                }
                textInput.text = input
            }
        }

    }
    private fun handleBackspace(){
        if (input.isNotEmpty()){
            input = input.dropLast(1)
            textInput.text = input
        }
    }

    private fun clearAll(){
        input = ""
        output = ""
        textInput.text = ""
        textDisplay.text = ""
    }

    private fun addParenttheses(){
        if (input.isNotEmpty() && input.last() != '('){
            input += "("
        }else{
            input += ")"
        }
        textInput.text = input
    }
    private fun calculateResult() {
        try {
            val expression = input.replace("÷", "/").replace("×", "*")
            val result = Expression(expression).eval().toString()
            output = result
            textDisplay.text = input
            textInput.text = output
            input = output
        } catch (e: Exception) {
            textInput.text = "Error"
            input = ""
        }
    }
}